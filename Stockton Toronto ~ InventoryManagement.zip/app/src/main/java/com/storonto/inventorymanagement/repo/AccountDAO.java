package com.storonto.inventorymanagement.repo;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.storonto.inventorymanagement.model.Account;

import java.util.List;

@Dao
public interface AccountDAO {
    @Query("SELECT * FROM Account WHERE id = :id")
    Account getAccount(long id);

    @Query("SELECT * FROM Account WHERE username = :username")
    Account getAccount(String username);

    @Query("SELECT * FROM Account ORDER BY username COLLATE NOCASE")
    List<Account> getAccounts();

    @Insert(onConflict = OnConflictStrategy.ABORT)
    long addAccount(Account account);

    @Update
    void updateAccount(Account account);

    @Delete
    void deleteAccount(Account account);
}
