package com.storonto.inventorymanagement.model;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;

import static androidx.room.ForeignKey.CASCADE;

@Entity(foreignKeys = @ForeignKey(entity = Account.class, parentColumns = "id",
        childColumns = "account_id", onDelete = CASCADE))
public class Item {
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    private long mId;

    @ColumnInfo(name = "text")
    private String mText;

    @ColumnInfo(name = "amount")
    private String mAmount;

    @ColumnInfo(name = "account_id")
    private long mAccountId;

    public Item(String text, String amount, long accountId) {
        mText = text;
        mAmount = amount;
        mAccountId = accountId;
    }

    public long getId() {
        return mId;
    }

    public void setId(long mId) {
        this.mId = mId;
    }

    public String getText() {
        return mText;
    }

    public void setText(String mText) {
        this.mText = mText;
    }

    public String getAmount() {
        return mAmount;
    }

    public void setAmount(String mAmount) {
        this.mAmount = mAmount;
    }

    public long getAccountId() {
        return mAccountId;
    }

    public void setAccountId(long mAccountId) {
        this.mAccountId = mAccountId;
    }
}
