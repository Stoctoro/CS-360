package com.storonto.inventorymanagement.repo;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.storonto.inventorymanagement.model.Item;

import java.util.List;

@Dao
public interface ItemDAO {
    @Query("SELECT * FROM Item WHERE id = :id")
    Item getItem(long id);

    @Query("SELECT * FROM Item WHERE account_id = :account_id ORDER BY " +
            "text COLLATE NOCASE")
    List<Item> getItems(long account_id);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long addItem(Item item);

    @Update
    void updateItem(Item item);

    @Delete
    void deleteItem(Item item);
}
