package com.storonto.inventorymanagement.repo;

import androidx.room.Database;
import androidx.room.RoomDatabase;

import com.storonto.inventorymanagement.model.Account;
import com.storonto.inventorymanagement.model.Item;

@Database(entities = {Account.class, Item.class}, version = 1)
public abstract class InventoryDatabase extends RoomDatabase {
    public abstract AccountDAO accountDAO();
    public abstract ItemDAO itemDAO();
}
