package com.storonto.inventorymanagement.viewmodel;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;

import com.storonto.inventorymanagement.model.Item;
import com.storonto.inventorymanagement.repo.InventoryRepository;

import java.util.List;

public class ItemListViewModel extends AndroidViewModel {
    private final InventoryRepository mInvRepo;

    public ItemListViewModel(Application application) {
        super(application);
        mInvRepo = InventoryRepository.getInstance(application.getApplicationContext());
    }

    public List<Item> getItems(long accountId) {
        return mInvRepo.getItems(accountId);
    }

    public Item getItem(long id) {
        return mInvRepo.getItem(id);
    }

    public void updateItem(Item item) {
        mInvRepo.updateItem(item);
    }

    public void deleteItem(Item item) {
        mInvRepo.deleteItem(item);
    }

    public void addItem(Item item) {
        mInvRepo.addItem(item);
    }
}
