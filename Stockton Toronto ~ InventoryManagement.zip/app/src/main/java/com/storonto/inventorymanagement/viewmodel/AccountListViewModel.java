package com.storonto.inventorymanagement.viewmodel;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;

import com.storonto.inventorymanagement.repo.InventoryRepository;
import com.storonto.inventorymanagement.model.Account;

import java.util.List;

public class AccountListViewModel extends AndroidViewModel {
    private final InventoryRepository mInvRepo;

    public AccountListViewModel(Application application) {
        super(application);
        mInvRepo = InventoryRepository.getInstance(application.getApplicationContext());
    }

    public List<Account> getAccounts() {
        return mInvRepo.getAccounts();
    }

    public Account getAccount(String username) {
        return mInvRepo.getAccount(username);
    }

    public long addAccount(Account account) {
        return mInvRepo.addAccount(account);
    }
}
