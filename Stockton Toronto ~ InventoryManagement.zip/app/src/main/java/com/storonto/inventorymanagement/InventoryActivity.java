package com.storonto.inventorymanagement;

import static java.lang.Long.parseLong;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.PackageManagerCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;
import com.storonto.inventorymanagement.model.Item;
import com.storonto.inventorymanagement.viewmodel.ItemListViewModel;

import java.util.ArrayList;
import java.util.List;

// Class for the recycling inventory activity
// Displays Item objects
// Can launch ItemActivity
public class InventoryActivity extends AppCompatActivity {

    private final int PERMISSION_REQUEST_CODE = 200;
    public static final String EXTRA_ACCOUNT_ID = "com.storonto.inventorymanager.account_id";
    public static final String EXTRA_TRY_SMS = "com.storonto.inventorymanager.try_sms";
    private long mAccountId;
    private boolean mTrySMS;
    private ItemListViewModel mItemListViewModel;
    private ItemAdapter mItemAdapter;
    private RecyclerView mRecyclerView;
    private static final long mNotifyThreshold = 1;
    private String mNotifyText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);
        Toolbar invToolbar = (Toolbar) findViewById(R.id.toolbar);
        invToolbar.showOverflowMenu();
        setSupportActionBar(invToolbar);

        mNotifyText = getString(R.string.notify_text);

        mItemListViewModel = new ItemListViewModel(getApplication());

        findViewById(R.id.addItemButton).setOnClickListener(view -> addItemClick());

        mRecyclerView = findViewById(R.id.itemRecyclerView);

        Intent intent = getIntent();
        mAccountId = intent.getLongExtra(EXTRA_ACCOUNT_ID, 0L);
        mTrySMS = intent.getBooleanExtra(EXTRA_TRY_SMS, false);
        updateUI(mItemListViewModel.getItems(mAccountId));
    }

    @Override
    protected void onStop() {
        super.onStop();

        // Try to send an SMS notification
        if(mTrySMS && checkSmsPermissions())
            sendSmsNotification();
    }

    // Method for updating the recycler view after making changes to the list of items
    private void updateUI(List<Item> itemList) {

        mItemAdapter = new ItemAdapter(itemList);
        mRecyclerView.setAdapter(mItemAdapter);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
    }

    // Starts new ItemActivity with account id as an extra
    private void addItemClick() {
        Intent intent = new Intent(InventoryActivity.this, ItemActivity.class);
        intent.putExtra(EXTRA_ACCOUNT_ID, mAccountId);
        startActivity(intent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.appbar_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem selection) {
        if (selection.getItemId() == R.id.action_enable_sms) {
            if(!checkSmsPermissions())
                requestSmsPermissions();
            return true;
        }
        else
            return super.onOptionsItemSelected(selection);

    }

    // Checks to see if app has required permissions for SMS notifications
    private boolean checkSmsPermissions() {
        return (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED
                && ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED
                && ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_NUMBERS) == PackageManager.PERMISSION_GRANTED);
    }

    // Requests permissions for SMS notifications
    private void requestSmsPermissions() {

        if (shouldShowRequestPermissionRationale(Manifest.permission.SEND_SMS)) {
            showRationaleMessage();
        }
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS,
                Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_PHONE_NUMBERS}, PERMISSION_REQUEST_CODE);
    }

    // Sends SMS notification if any items are at/below the notify threshold
    private void sendSmsNotification() {

        List<String> lowItems = new ArrayList<>();

        for (Item item : mItemListViewModel.getItems(mAccountId)) {

            try {
                if (parseLong(item.getAmount()) <= mNotifyThreshold) {
                    lowItems.add(item.getText());
                }
            }
            catch(NumberFormatException e){
                // Amount cannot be parsed to long, skip to next item
                continue;
            }
        }

        if (!lowItems.isEmpty()) {
            StringBuilder stringBuilder = new StringBuilder(mNotifyText);

            for (String item : lowItems) {
                String itemString = "\n     " + item + ",";
                stringBuilder.append(itemString);
            }

            TelephonyManager telephonyManager = (TelephonyManager)getApplicationContext().getSystemService(Context.TELEPHONY_SERVICE);

            @SuppressLint("MissingPermission") // Permissions were already checked before executing this method
            String phoneNumber = telephonyManager.getLine1Number();

            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, phoneNumber, stringBuilder.toString(), null, null);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0) {

                boolean smsAccepted = grantResults[0] == PackageManager.PERMISSION_GRANTED;

                if (smsAccepted) {
                    Toast toast = Toast.makeText(this, "SMS Permissions Granted", Toast.LENGTH_SHORT);
                    toast.show();
                } else {
                    Toast toast = Toast.makeText(this, "SMS Permissions Denied", Toast.LENGTH_SHORT);
                    toast.show();
                }
            }
        }
    }

    // Shows rationale for permissions
    private void showRationaleMessage() {
        new AlertDialog.Builder(InventoryActivity.this)
                .setMessage(R.string.rationale)
                .setNeutralButton(R.string.understood, null)
                .create()
                .show();
    }

    // ViewHolder class for Item objects in the recycler
    private class ItemHolder extends RecyclerView.ViewHolder
            implements View.OnClickListener {

        private Item mItem;
        private final TextView mItemTextView;
        private final TextView mItemAmountView;

        public ItemHolder(LayoutInflater inflater, ViewGroup parent) {
            super(inflater.inflate(R.layout.recycler_view_items, parent, false));
            itemView.setOnClickListener(this);
            mItemTextView = itemView.findViewById(R.id.item_text_view);
            mItemAmountView = itemView.findViewById(R.id.item_amount_view);
        }

        public void bind(Item item, int position) {
            mItem = item;
            mItemTextView.setText(item.getText());
            mItemAmountView.setText(item.getAmount());
        }

        // Starts ItemActivity with both account id and item id as extras
        @Override
        public void onClick(View view) {
            Intent intent = new Intent(InventoryActivity.this, ItemActivity.class);
            intent.putExtra(ItemActivity.EXTRA_ITEM_ID, mItem.getId());
            intent.putExtra(InventoryActivity.EXTRA_ACCOUNT_ID, mAccountId);

            startActivity(intent);
        }
    }

    // Adapter class for Item objects
    private class ItemAdapter extends RecyclerView.Adapter<ItemHolder> {

        private final List<Item> mItemList;

        public ItemAdapter(List<Item> items) {
            mItemList = items;
        }

        @NonNull
        @Override
        public ItemHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(getApplicationContext());
            return new ItemHolder(layoutInflater, parent);
        }

        @Override
        public void onBindViewHolder(ItemHolder holder, int position) {
            holder.bind(mItemList.get(position), position);
        }

        @Override
        public int getItemCount() {
            return mItemList.size();
        }
    }
}