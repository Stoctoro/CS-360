package com.storonto.inventorymanagement;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.widget.Toolbar;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Locale;

import com.storonto.inventorymanagement.model.Account;
import com.storonto.inventorymanagement.viewmodel.AccountListViewModel;

// Class for the Login screen activity
// This is the initial activity upon starting the app
// Allows creation of new Account objects in database
// Can launch InventoryActivity
public class LoginActivity extends AppCompatActivity {

    private EditText mPassword;
    private EditText mUsername;
    private View mLoginButton;
    private View mCreateButton;
    private MessageDigest mMessageDigest;
    private static final String mSalt = "sOmcTeQYGY69OqYKknaGXQ8xfnXhYeXQ";
    private AccountListViewModel mAccountListViewModel;
    private long mAccountId = 0L;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        Toolbar loginToolbar = (Toolbar) findViewById(R.id.toolbarLogin);
        loginToolbar.hideOverflowMenu();
        setSupportActionBar(loginToolbar);

        mPassword = findViewById(R.id.passwordEdit);
        mUsername = findViewById(R.id.usernameEdit);
        mLoginButton = findViewById(R.id.buttonLogin);
        mCreateButton = findViewById(R.id.buttonCreate);

        // Attempt to prepare MessageDigest object using SHA-256 hashing algorithm
        try {
            mMessageDigest = MessageDigest.getInstance("SHA-256");
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }

        mAccountListViewModel = new AccountListViewModel(getApplication());

        mLoginButton.setOnClickListener(view -> {
            if(Login()) {

                // Create new InventoryActivity based on the id of the Account that logged in
                Intent intent = new Intent(LoginActivity.this, InventoryActivity.class);
                intent.putExtra(InventoryActivity.EXTRA_ACCOUNT_ID, mAccountId);

                // set extra for sending SMS notification
                intent.putExtra(InventoryActivity.EXTRA_TRY_SMS, true);

                startActivity(intent);
            }
            else {
                Toast toast = Toast.makeText(this, "Login Failed", Toast.LENGTH_SHORT);
                toast.show();
            }
        });

        mCreateButton.setOnClickListener(view -> {
            Create();
        });
    }

    // Checks to see if login credentials are valid
    private boolean Login() {
        String username = ReadUsername();
        String password = ReadPassword();

        Account account = mAccountListViewModel.getAccount(username);
        if(account != null) {
            if (account.getPassword().equals(password)) {
                mAccountId = account.getId();
                return true;
            }
        }
        return false;
    }

    // Method for creating new Account object
    private void Create() {
        String username = ReadUsername();
        String password = ReadPassword();

        Account account = mAccountListViewModel.getAccount(username);
        if(account == null) {
            mAccountListViewModel.addAccount(new Account(username, password));
            Toast.makeText(this, "Account Successfully Created", Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(this, "Username Already Taken", Toast.LENGTH_SHORT).show();
        }
    }

    // Returns the string value in the username text box
    private String ReadUsername() {
        return mUsername.getText().toString().toLowerCase(Locale.ROOT);
    }

    // Concatenates a salt value to the end of the string within the password text box
    // and runs the result through a hashing algorithm
    private String ReadPassword() {
        mMessageDigest.update((mPassword.getText().toString() + mSalt).getBytes());
        return new String(mMessageDigest.digest());
    }
}