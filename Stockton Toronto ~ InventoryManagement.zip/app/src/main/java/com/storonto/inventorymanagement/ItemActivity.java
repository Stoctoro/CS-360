package com.storonto.inventorymanagement;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import com.storonto.inventorymanagement.model.Item;
import com.storonto.inventorymanagement.viewmodel.ItemListViewModel;

// Class for item edit activity
// Allows for creation and modification of Item objects in database
// Can launch InventoryActivity
public class ItemActivity extends AppCompatActivity {

    private ItemListViewModel mItemListViewModel;
    public static final String EXTRA_ITEM_ID = "com.storonto.inventorymanager.item_id";
    private long mId;
    private long mAccountId;
    private EditText mText;
    private EditText mAmount;
    private Button mConfirm;
    private Button mCancel;
    private Button mDelete;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent = getIntent();

        mId = intent.getLongExtra(EXTRA_ITEM_ID, 0L);
        mAccountId = intent.getLongExtra(InventoryActivity.EXTRA_ACCOUNT_ID, 0L);

        mItemListViewModel = new ItemListViewModel(getApplication());

        setContentView(R.layout.activity_item);
        mText = findViewById(R.id.dialogText);
        mAmount = findViewById(R.id.dialogNumber);
        mConfirm = findViewById(R.id.buttonConfirm);
        mCancel = findViewById(R.id.buttonCancel);
        mDelete = findViewById(R.id.buttonDelete);

        if (mId != 0L) {
            Item item = mItemListViewModel.getItem(mId);
            mText.setText(item.getText());
            mAmount.setText(item.getAmount());
        }

        mConfirm.setOnClickListener(view -> Confirm());
        mCancel.setOnClickListener(view -> Cancel());
        mDelete.setOnClickListener(view -> Delete());
    }

    // launches InventoryActivity without making any database changes
    private void Cancel() {
        Intent intent = new Intent(ItemActivity.this, InventoryActivity.class);
        intent.putExtra(InventoryActivity.EXTRA_ACCOUNT_ID, mAccountId);

        // prevents SMS notification from firing after evey item edit
        intent.putExtra(InventoryActivity.EXTRA_TRY_SMS, false);
        startActivity(intent);
    }

    // Creates new Item object that replaces the existing one in the database if there was one
    private void Confirm() {

        Item item;

        if(mId != 0L) {
            item = mItemListViewModel.getItem(mId);
            item.setText(mText.getText().toString());
            item.setAmount(mAmount.getText().toString());
        }
        else {
            item = new Item(mText.getText().toString(), mAmount.getText().toString(), mAccountId);
        }

        mItemListViewModel.addItem(item);

        Cancel();
    }

    // Removes the Item from the database
    private void Delete() {
        if(mId != 0L) {
            Item item = mItemListViewModel.getItem(mId);
            mItemListViewModel.deleteItem(item);
        }

        Cancel();
    }
}