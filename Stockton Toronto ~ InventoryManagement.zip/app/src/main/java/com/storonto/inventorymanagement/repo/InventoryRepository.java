package com.storonto.inventorymanagement.repo;

import android.content.Context;
import androidx.room.Room;
import com.storonto.inventorymanagement.model.Account;
import com.storonto.inventorymanagement.model.Item;
import java.util.List;
import androidx.lifecycle.LiveData;

public class InventoryRepository {
    private static InventoryRepository mInvRepo;
    private final AccountDAO mAccountDao;
    private final ItemDAO mItemDao;

    public static InventoryRepository getInstance(Context context) {
        if (mInvRepo == null) {
            mInvRepo = new InventoryRepository(context);
        }
        return mInvRepo;
    }

    private InventoryRepository(Context context) {
        InventoryDatabase database = Room.databaseBuilder(context, InventoryDatabase.class, "inventory.db")
                .allowMainThreadQueries()
                .build();

        mAccountDao = database.accountDAO();
        mItemDao = database.itemDAO();
    }

    public long addAccount(Account account) {
        long accountId = mAccountDao.addAccount(account);
        account.setId(accountId);
        return accountId;
    }

    public Account getAccount(long accountId) {
        return mAccountDao.getAccount(accountId);
    }

    public Account getAccount(String username) {
        return mAccountDao.getAccount(username);
    }

    public List<Account> getAccounts() {
        return mAccountDao.getAccounts();
    }

    public Item getItem(long itemId) {
        return mItemDao.getItem(itemId);
    }

    public List<Item> getItems(long accountId) {
        return mItemDao.getItems(accountId);
    }

    public void addItem(Item item) {
        long itemId = mItemDao.addItem(item);
        item.setId(itemId);
    }

    public void updateItem(Item item) {
        mItemDao.updateItem(item);
    }

    public void deleteItem(Item item) {
        mItemDao.deleteItem(item);
    }

}
